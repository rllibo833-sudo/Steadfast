# Product goal

## Outcome
Provide a local-first, deterministic CLI that flags repository scope violations, likely documentation drift, missing verification evidence, and product-code budget overruns.

## Non-goals
- Do not generate or rewrite application code.
- Do not run a hosted service or require model/API credentials.
- Do not auto-expand the roadmap or modify project documentation silently.
- Do not claim static checks prove semantic correctness.

## Acceptance criteria
- [ ] `steadfast init` creates policy and evidence starter files without overwriting existing files.
- [ ] Scope checks flag changed paths outside the configured allowlist.
- [ ] Audit reports likely documentation drift and missing evidence.
- [ ] Product-code budget is configurable and defaults to 20,000 counted lines.
- [ ] Unit tests pass using the standard library test runner.

## Scope change process
Any new capability must be proposed separately and approved by a maintainer before implementation.
