# Changelog

## 0.1.0 — initial scaffold
- Local-first CLI for scope, documentation drift, evidence, and code budget checks.
- GitHub Actions example.
- Five portable agent skills.
- Standard-library tests.
- Verification remains pending until executed in a real environment.
