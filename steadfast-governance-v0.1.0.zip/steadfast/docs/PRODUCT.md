# Product definition

## User problem
Coding agents can change implementation while leaving documentation stale, silently expand scope, or report completion without sufficient evidence.

## Product
Steadfast is a local-first governance CLI plus portable skills and a GitHub Actions workflow. It checks repository policy; it does not replace coding agents, code review, or semantic tests.

## First-version boundaries
- One local repository at a time.
- Deterministic checks only; no AI API or hosted backend.
- Configurable path allowlist and documentation paths.
- Basic implementation-to-documentation drift signals.
- Required evidence file validation.
- Product-code line budget.
- Markdown/JSON report output.

## Success criteria
A maintainer can install it, define one product goal, run checks locally and in CI, and see actionable findings with file paths. It should be possible to disable any check by editing policy, and the tool must not silently edit project files.

## Out of scope
Hosted dashboard, multi-agent orchestration, automatic code rewriting, enterprise analytics, paid service, and claims of fully automated semantic verification.
