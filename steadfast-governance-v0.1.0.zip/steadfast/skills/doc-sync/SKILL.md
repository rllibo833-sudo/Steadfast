---
name: doc-sync
description: Keep repository documentation aligned with actual code and test evidence.
---

# Documentation synchronization

1. Identify code behavior changed in the current diff.
2. Find the existing README, specification, architecture, and usage docs that describe that behavior.
3. Update only the documents made stale by this change; avoid duplicate or speculative docs.
4. Verify every new feature claim against implementation and tests.
5. Remove or qualify claims that lack evidence.
6. Run `steadfast audit`; explain any remaining drift warning.
7. Never invent benchmark numbers, test results, compatibility, or release status.
