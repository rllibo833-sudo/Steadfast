---
name: evidence-check
description: Verify claims of completion against commands, tests, outputs, and artifacts.
---

# Evidence check

1. For each acceptance criterion, name the exact command or inspection used.
2. Record exit code and relevant observed output in `evidence/verification.md`.
3. Distinguish test success from product completeness.
4. Run `steadfast evidence-check`.
5. Never turn a planned test into a passing result.
6. State limitations and unverified behavior explicitly.
