---
name: release-readiness
description: Prepare a release only after scope, docs, tests, and evidence agree.
---

# Release readiness

- Run `steadfast audit` and `steadfast evidence-check`.
- Verify release notes match the diff.
- Confirm documented installation and usage commands are executable.
- Confirm no secrets, credentials, or local artifacts were committed.
- Confirm version and compatibility statements are evidenced.
- Report blockers instead of bypassing failed checks.
