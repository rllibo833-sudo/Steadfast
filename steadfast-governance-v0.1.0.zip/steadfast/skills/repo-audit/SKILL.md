---
name: repo-audit
description: Audit repository reality before planning or editing. Use when starting work in an existing codebase.
---

# Repository audit

1. Inspect current source, tests, workflows, and recent diffs before trusting prose.
2. Read `.steadfast/goal.md` and `.steadfast/policy.json`.
3. Run `steadfast audit` and report findings with paths and evidence.
4. Separate verified facts, hypotheses, and unknowns.
5. Do not add roadmap items or change scope during an audit.
6. Do not claim a test passed unless its command and result were observed.
7. Prefer a minimal actionable change over a broad rewrite.
