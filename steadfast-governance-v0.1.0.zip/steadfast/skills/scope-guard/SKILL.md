---
name: scope-guard
description: Prevent coding-agent work from expanding beyond the agreed product outcome.
---

# Scope guard

Before editing:
- Read `.steadfast/goal.md`.
- List intended files and tie each to an acceptance criterion.
- Check changed paths with `steadfast scope-check`.

During work:
- Do not add capabilities merely because they seem useful.
- Do not introduce a new framework, service, database, or dependency without necessity and approval.
- If a requirement is ambiguous or outside scope, stop and report the smallest decision needed.

Before completion:
- Check the final diff against the original goal.
- Remove unrelated changes.
- Update the goal only through an explicit maintainer-approved scope change.
