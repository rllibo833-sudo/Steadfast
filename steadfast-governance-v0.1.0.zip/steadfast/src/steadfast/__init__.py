"""Steadfast repository governance."""
__version__ = "0.1.0"
