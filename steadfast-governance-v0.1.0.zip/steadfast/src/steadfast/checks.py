from __future__ import annotations
import fnmatch, json, re
from pathlib import Path
from typing import Any
from .gitops import changed_paths, git, is_repo, untracked_paths
from .policy import load_policy

def matches(path: str, patterns: list[str]) -> bool:
    return any(fnmatch.fnmatchcase(path, pattern) or
               (pattern.endswith("/**") and path.startswith(pattern[:-3]))
               for pattern in patterns)

def product_code_lines(repo: Path, policy: dict[str, Any]) -> tuple[int, list[str]]:
    total, counted = 0, []
    ignored = policy.get("ignored_paths", [])
    impl = policy.get("implementation_paths", ["src/**"])
    for path in repo.rglob("*"):
        if not path.is_file():
            continue
        rel = path.relative_to(repo).as_posix()
        if matches(rel, ignored) or not matches(rel, impl):
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except (UnicodeDecodeError, OSError):
            continue
        # Count nonblank, non-comment lines conservatively for common code formats.
        suffix = path.suffix.lower()
        for line in text.splitlines():
            stripped = line.strip()
            if not stripped:
                continue
            if suffix in {".py", ".sh", ".yml", ".yaml"} and stripped.startswith("#"):
                continue
            if suffix in {".js", ".ts", ".c", ".h", ".cpp", ".java", ".go", ".rs"} and stripped.startswith("//"):
                continue
            total += 1
        counted.append(rel)
    return total, counted

def scope_findings(repo: Path, policy: dict[str, Any], paths: list[str] | None = None) -> list[dict[str, str]]:
    if paths is None:
        paths = changed_paths(repo)
    findings = []
    allowed = policy.get("allowed_paths", [])
    ignored = policy.get("ignored_paths", [])
    for path in paths:
        if matches(path, ignored):
            continue
        if not matches(path, allowed):
            findings.append({"severity":"error","code":"SCOPE_OUTSIDE_ALLOWLIST",
                             "path":path,"message":"Changed path is outside .steadfast/policy.json allowed_paths."})
    return findings

def doc_drift_findings(repo: Path, policy: dict[str, Any], paths: list[str] | None = None) -> list[dict[str, str]]:
    if paths is None:
        paths = changed_paths(repo)
    docs = policy.get("documentation_paths", [])
    impl = policy.get("implementation_paths", ["src/**"])
    changed_impl = [p for p in paths if matches(p, impl)]
    changed_docs = [p for p in paths if matches(p, docs)]
    findings = []
    if changed_impl and not changed_docs:
        findings.append({"severity":"warning","code":"DOCS_NOT_CHANGED",
                         "path":", ".join(changed_impl[:8]),
                         "message":"Implementation changed but no configured documentation path changed. Confirm docs are still accurate; add/update docs or record why not needed."})
    if changed_docs and not changed_impl:
        findings.append({"severity":"info","code":"DOCS_ONLY_CHANGE",
                         "path":", ".join(changed_docs[:8]),
                         "message":"Documentation changed without implementation changes. Verify claims against current code and tests."})
    # Flag likely stale absolute claims in docs, without claiming semantic understanding.
    for pattern in docs:
        for path in repo.glob(pattern):
            if not path.is_file():
                continue
            try: content = path.read_text(encoding="utf-8")
            except (OSError, UnicodeDecodeError): continue
            if re.search(r"\b(100% complete|fully implemented|all tests pass|production-ready)\b", content, re.I):
                findings.append({"severity":"warning","code":"UNVERIFIED_ABSOLUTE_CLAIM","path":str(path.relative_to(repo)),"message":"Documentation contains a strong completion claim. Attach fresh evidence or qualify the claim."})
    # Deduplicate repeated claims by path/code.
    seen, unique = set(), []
    for item in findings:
        key = (item["code"], item["path"])
        if key not in seen:
            unique.append(item); seen.add(key)
    return unique

def evidence_findings(repo: Path, policy: dict[str, Any]) -> list[dict[str, str]]:
    findings = []
    for item in policy.get("required_evidence", []):
        path = repo / item
        if not path.exists():
            findings.append({"severity":"error","code":"EVIDENCE_MISSING","path":item,
                             "message":"Required evidence file is missing."})
        elif not path.is_file() or len(path.read_text(encoding="utf-8").strip()) < 40:
            findings.append({"severity":"error","code":"EVIDENCE_EMPTY","path":item,
                             "message":"Evidence file is empty or too short to contain a meaningful verification record."})
        else:
            content = path.read_text(encoding="utf-8")
            if not re.search(r"(?i)(command|test|exit code|result|passed|failed)", content):
                findings.append({"severity":"warning","code":"EVIDENCE_UNSTRUCTURED","path":item,
                                 "message":"Evidence should record exact commands and observed results."})
    return findings

def policy_findings(repo: Path, policy: dict[str, Any]) -> list[dict[str, str]]:
    findings = []
    goal_path = repo / ".steadfast" / "goal.md"
    if not goal_path.exists():
        findings.append({"severity":"error","code":"GOAL_MISSING","path":".steadfast/goal.md",
                         "message":"Single active product goal is missing."})
    else:
        goal = goal_path.read_text(encoding="utf-8")
        for required in ("## Outcome", "## Non-goals", "## Acceptance criteria"):
            if required not in goal:
                findings.append({"severity":"error","code":"GOAL_SECTION_MISSING","path":".steadfast/goal.md",
                                 "message":f"Required section missing: {required}"})
        active = len(re.findall(r"(?m)^\s*[-*]\s+\[\s\]", goal))
        if active > int(policy.get("max_active_goals", 3)) * 3:
            findings.append({"severity":"warning","code":"TOO_MANY_OPEN_CHECKS","path":".steadfast/goal.md",
                             "message":"Goal contains many unchecked items; split only after the current outcome is delivered."})
        for phrase in policy.get("forbidden_roadmap_phrases", []):
            if phrase.lower() in goal.lower():
                findings.append({"severity":"warning","code":"ROADMAP_SCOPE_SIGNAL","path":".steadfast/goal.md",
                                 "message":f"Goal contains vague expansion phrase: {phrase}"})
    count, _ = product_code_lines(repo, policy)
    budget = policy["product_code_budget"]
    if count > budget:
        findings.append({"severity":"error","code":"PRODUCT_CODE_BUDGET_EXCEEDED","path":"src","message":f"Product code has {count} counted lines; configured limit is {budget}."})
    return findings

def run_audit(repo: Path, base: str | None = None) -> dict[str, Any]:
    policy = load_policy(repo)
    paths = changed_paths(repo, base) if is_repo(repo) else []
    code_lines, code_files = product_code_lines(repo, policy)
    findings = []
    findings += scope_findings(repo, policy, paths)
    findings += doc_drift_findings(repo, policy, paths)
    findings += evidence_findings(repo, policy)
    findings += policy_findings(repo, policy)
    return {"tool":"steadfast","version":"0.1.0","repository":str(repo),
            "changed_paths":paths,"product_code_lines":code_lines,
            "product_code_budget":policy["product_code_budget"],
            "counted_code_files":len(code_files),"findings":findings,
            "summary":{"errors":sum(f["severity"]=="error" for f in findings),
                       "warnings":sum(f["severity"]=="warning" for f in findings),
                       "info":sum(f["severity"]=="info" for f in findings)},
            "passed":not any(f["severity"]=="error" for f in findings)}
